
#Imports extra code
import string
import random
import nltk


#From A3-Chatbots
def selector(input_list, check_list, return_list):
    
    #Defines output as None
    output = None
    
    #Loops through each element in input_list
    for item in input_list:
        
        #Uses a conditional to check if the current element is in check_list
        if item in check_list:
            
            #Assigns output as the returned value of calling the random.choice function on return_list
            output = random.choice(return_list)
            
            #Breaks out of for loop
            break
            
    return output


#This cell contains a list of the types of food and the information for two restaurants per type of food 
#Restaurant information from yelp.com
food_type_list = ['Korean', 'Japanese', 'Vietnamese', 'Mexican', 'American', 'Italian', 'Greek']        

korean_food1 = ["Korean", "Grandma Tofu and Korean BBQ", "3.5 stars", "4425 Convoy St. San Diego, CA 92111"]

korean_food2 = ["Korean", "Cross Street Chicken and Beer", "4.5 stars", "4403 Convoy St. San Diego, CA 92111"]

japan_food1 = ["Japanese", "Katsu Cafe", "4 stars", "7305 Clairemont Mesa Blvd Ste B San Diego, CA 92111"]

japan_food2 = ["Japanese", "Tajima Izakaya", "4 stars", "4411 Mercury St. Ste 110 San Diego, CA 92111"]

viet_food1 = ["Vietnamese", "Phuong Trang", "4 stars", "4170 Convoy St. San Diego, CA 92111"]

viet_food2 = ["Vietnamese", "Pho Duyen Mai", "4.5 stars", "5375 Kearny Villa Rd. Ste 111 San Diego, CA 92123"]

mex_food1 = ["Mexican", "Lolita’s Mexican Food", "4 stars", "7305 Clairemont Mesa Blvd. Ste A San Diego, CA 92111"]

mex_food2 = ["Mexican", "Oscar’s Mexican Seafood", "4.5 stars", "703 Turquoise St. San Diego, CA 92109"]

usa_food1 = ["American", "Werewold", "4.5 stars", "627 4th Ave. San Diego, CA 92101"]

usa_food2 = ["American", "Chick-fil-A", "3 stars", "5955 Balboa Ave. San Diego, CA 92111"]

italy_food1 = ["Italian", "Bencotto Italian Kitchen", "4 stars", "750 W Fir St. San Diego, CA 92101"]

italy_food2 = ["Italian", "Buona Forchetta", "4.5 stars", "3001 Beech St. San Diego, CA 92102"]

greek_food1 = ["Greek", "Olympic Cafe", "4.5 stars", "2310 University Ave. San Diego, CA 92104"]

greek_food2 = ["Greek", "Taste of Athens", "4.5 stars", "6171 Mission Gorge Rd. Ste 109 San Diego, CA 92120"]


def choose_type_of_food(input_string):
    """Function that chooses a random type of food when user inputs question
    of what type of food to get."""
    
    #List of words/phrases to prompt the Chatbot to provide a type of food
    greet_list = ['what kind of food should I get', 'of', 'food', 'What', 'type', 'of', 'food', 
                  'Recommend a type of food', 'recommend']
    
    #List of possible words/phrases that the user may input
    input_list = ['what', 'kind', 'should', 'I get', 'recommend', 'type', 'what kind of food should I get']
    
    #Defines output and out_msg as empty strings
    output = ''
    out_msg = ''
    
    #Defines food_info as an empty list
    food_info = []
    
    #Set value of output to random food type 
    output = selector(input_list, greet_list, food_type_list)
    
    #Check if output is a certain type of food
    #Then set food_info randomly to 1 of 2 lists of food information corresponding to the type of food
    if output == 'Korean':
        food_info = korean_food1 or korean_food2
    
    elif output == 'Japanese':
        food_info = japan_food1 or japan_food2
    
    elif output == 'Vietnamese':
        food_info = viet_food1 or viet_food2
    
    elif output == 'Mexican':
        food_info = mex_food1 or mex_food2
    
    elif output == 'American':
        food_info = usa_food1 or usa_food2
    
    elif output == 'Italian':
        food_info = italy_food1 or italy_food2
    
    elif output == 'Greek':
        food_info = greek_food1 or greek_food2
    
    #Sets an output message
    out_msg = 'You should go to' + ' ' + food_info[1] + ' ' + 'located at' + ' ' + food_info[3]
    print('OUTPUT:', out_msg)  
    

def choose_rating(input_string):
        """Function that outputs a restaurant based on the user's desired Yelp rating."""
        
        #Defines a list of star ratings        
        rating_words = ['3 stars', '3.5 stars', '4 stars', '4.5 stars']
    
        #Checks to see if the restaurant's star rating matches the user's prefered star rating
        #Then sets food_info to a restaurant's information with the star rating
        if rating_words[0] in input_string:
            
            food_info = usa_food2

        elif rating_words[1] in input_string:

            food_info = korean_food1

        elif rating_words[2] in input_string:

            food_info = japan_food1 or japan_food2 or viet_food1 or mex_food1 or italy_food1

        elif rating_words[3] in input_string:
            food_info = korean_food2 or viet_food2 or mex_food2 or usa_food1 or italy_food2 or greek_food1 or greek_food2
        
        #Sets an output message
        out_msg = 'You should go to' + ' ' + food_info[1] + ' ' + 'located at' + ' ' + food_info[3]
        
        print('OUTPUT:', out_msg)
        

def give_rec(input_string):
       """Function that outputs 1 of 2 restaurants according to the type of food the user inputs"""
       
       #Checks to see which type of food the user inputs and then outputs 1 of 2 restaurants' information
       if 'Korean' or 'korean' in input_string:
           food_info = korean_food1 or korean_food2

       elif 'Japanese' or 'japanese' in input_string:
           food_info = japan_food1 or japan_food2
       
       elif 'Vietnamese' or 'vietnamese' in input_string:
           food_info = viet_food1 or viet_food2
       
       elif 'Mexican' or 'mexican' in input_string:
           food_info = mex_food1 or mex_food2
       
       elif 'American' or 'american' in input_string:
           food_info = usa_food1 or usa_food2
       
       elif 'Italian' or 'italian' in input_string:
           food_info = italy_food1 or italy_food2
       
       elif 'Greek' or 'greek' in input_string:
           food_info = greek_food1 or greek_food2
       
       #Sets an output message
       out_msg = 'You should go to' + ' ' + food_info[1] + ' ' + 'located at' + ' ' + food_info[3]
       
       print('OUTPUT:', out_msg)
       

#Defines what the chatbot will respond to in regards to input greetings and sets a list of output greetings
in_greeting = ['Hi, I am hungry', 'Hello', 'hello', 'hi']
out_greeting = ['Hello there', 'I am here to help']   


#From A3-Chatbots
def remove_punctuation (input_string):
    #Defines out_string as an empty string
    out_string = ''
    
    #Loops through each character in input_string
    for char in input_string:
        
        #Checks to see if this character is not in string.punctuation
        if char not in string.punctuation:
            
            #Appends the current character to out_string
            out_string = out_string + char
        
    return out_string


#From A3-Chatbots
def prepare_text(input_string):
    #Defines out_list as an empty string
    out_list = []
    
    #Makes the string all lower case
    temp_string = input_string.lower()
    
    #Removes all punctuation from the string
    temp_string = remove_punctuation(temp_string)
    
    #Splits the string into words
    out_list = temp_string.split()
    
    return out_list


#Adopted from A3-Chatbots
def selector_new (input_list, check_list, return_list):
    """Similar to selector function from A3 with the addition of printing an output message 
        only if the value of out_msg is not None"""
    #Sets value of out_msg to None
    out_msg = None
    
     #Loops through each element in input_list
    for item in input_list:
        
        #Conditional to check if the current element is in check_list
        if item in check_list:
            
            #Assigns output as the returned value of calling the random.choice function on return_list
            out_msg = random.choice(return_list)
            
            break
    #Conditional to check if out_msg is not None         
    if out_msg != None:
        
        #Prints out value of out_msg if out_msg is not None
        print('OUTPUT:', out_msg) 


#Adopted from A3-Chatbots
def end_chat(input_list):
    """Function that ends chat when specified input is provided"""
    
    #Checks to see if thanks is in input
    if 'thanks' in input_list:
        
        #If it is then output is set to True
        output = True
    
    #If it is not then output is set to False
    else:
        output = False
        
    return output


# Adopted from Assignment 3: Chatbots
def food_chat_bot():
    """Main function to run the chatbot."""
    
    #Defines chat as True
    chat = True
    
    while chat:
        
        # Get a message from the user
        msg = input('INPUT :\t')
        out_msg = None

        # Prepare the input message
        msg = prepare_text(msg)

        # Check for an end msg 
        if end_chat(msg):
            out_msg = 'Enjoy your meal!'
            print('OUTPUT:', out_msg) 
            chat = False
        
        if not out_msg:
            
            #Checks to see if message from the user is a greeting
            if selector_new(msg, in_greeting, out_greeting):
                pass
            
            #Runs the choose_type_of_food function
            if choose_type_of_food(msg):
                break
            
            #Runs the choose_rating function
            elif choose_rating(msg):
                break
            
            #Runs the give_rec function
            elif give_rec(msg):
                break
            

#Ask for food recommendations!
food_chat_bot()

