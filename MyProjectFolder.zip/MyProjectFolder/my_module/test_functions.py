"""Test for my functions."""

from functions import choose_type_of_food, choose_rating

def test_choose_type_of_food():

    assert choose_type_of_food('what kind of food should I get') == list

def test_choose_rating():

    assert choose_rating('I want a restaurant with 3 stars') == 'You should go to Chick-fil-A located at 5955 Balboa Ave. San Diego, CA 92111'

    assert choose_rating('I want a restaurant with 3.5 stars') == 'You should go to Grandma Tofu and Korean BBQ located at 4425 Convoy St. San Diego, CA 92111'